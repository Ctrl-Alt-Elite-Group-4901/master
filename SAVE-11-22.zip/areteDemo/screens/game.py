# areteDemo/screens/game.py
from kivy.uix.screenmanager import Screen
from kivy.app import App
import areteDemo.auth as auth
from kivy.clock import Clock
from kivy.uix.popup import Popup
from kivy.uix.label import Label
import random

class GameScreen(Screen):
    def on_pre_enter(self):
        app = App.get_running_app()
        if not app.user_id:
            self.manager.current = "login"
            return
        # show a randomized "score" button or info - simple demo
        if "game_info" in self.ids:
            self.ids.game_info.text = "Press Play to simulate a game and record a score."

    def play_game(self):
        # Simulate a game score and record it
        app = App.get_running_app()
        if not app.user_id:
            self._show_message("You must be logged in.")
            return
        score = random.randint(1, 100)
        auth.add_score(app.user_id, score)
        self._show_message(f"Game finished! Score: {score}")

    def _show_message(self, text):
        popup = Popup(title="Game", content=Label(text=text), size_hint=(0.7, 0.35))
        popup.open()
