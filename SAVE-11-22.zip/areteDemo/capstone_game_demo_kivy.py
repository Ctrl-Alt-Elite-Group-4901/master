# areteDemo/capstone_game_demo_kivy.py

import json
import random
from kivy.uix.widget import Widget
from kivy.graphics import Color, Rectangle
from kivy.clock import Clock
from kivy.properties import NumericProperty, BooleanProperty, StringProperty
from kivy.app import App


class GameWidget(Widget):
    """
    The in-app mini-game widget.
    Provides:
        - countdown before start
        - active run timer
        - live score
        - end-of-run score saving
    """

    # Live game state
    countdown = NumericProperty(3)
    in_countdown = BooleanProperty(True)
    play_time = NumericProperty(0)
    current_score = NumericProperty(0)
    game_over = BooleanProperty(False)

    # Text displayed in the HUD
    hud_text = StringProperty("Starting...")

    # Internal bookkeeping
    _update_event = None

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        # Basic visual background
        with self.canvas:
            Color(0.1, 0.1, 0.1, 1)
            self.bg = Rectangle(size=self.size, pos=self.pos)

        self.bind(size=self._update_bg, pos=self._update_bg)

        # Begin countdown
        self.start_countdown()

    def _update_bg(self, *args):
        self.bg.size = self.size
        self.bg.pos = self.pos

    # ----------------------------------------------------------
    # COUNTDOWN
    # ----------------------------------------------------------
    def start_countdown(self):
        self.countdown = 3
        self.in_countdown = True
        self.hud_text = f"Starting in {self.countdown}"
        Clock.schedule_interval(self._countdown_tick, 1)

    def _countdown_tick(self, dt):
        self.countdown -= 1
        if self.countdown > 0:
            self.hud_text = f"Starting in {self.countdown}"
        else:
            self.hud_text = "GO"
            self.in_countdown = False
            Clock.unschedule(self._countdown_tick)
            self.start_game_loop()

    # ----------------------------------------------------------
    # MAIN GAME LOOP
    # ----------------------------------------------------------
    def start_game_loop(self):
        self.play_time = 0
        self.current_score = 0
        self.game_over = False

        self._update_event = Clock.schedule_interval(self.update, 1/60)

    def update(self, dt):
        """
        Called 60 times per second.
        Updates timer and score.
        """
        if self.game_over:
            return

        # Time elapsed
        self.play_time += dt

        # Example scoring: time * 10, plus randomness to imitate "distance"
        simulated_distance = int(self.play_time * 10)
        simulated_bonus = random.randint(0, 2)
        self.current_score = simulated_distance + simulated_bonus

        # HUD update
        self.hud_text = (
            f"Time: {self.play_time:.1f}s\n"
            f"Score: {self.current_score}"
        )

        # Example game-over condition (after 20 seconds)
        if self.play_time >= 20:
            self.end_game()

    # ----------------------------------------------------------
    # END GAME
    # ----------------------------------------------------------
    def end_game(self):
        if self.game_over:
            return

        self.game_over = True

        if self._update_event:
            Clock.unschedule(self._update_event)

        # Final HUD
        self.hud_text = (
            f"GAME OVER\n"
            f"Final Score: {self.current_score}"
        )

        # Attempt in-app save
        self._attempt_save_score()

    def _attempt_save_score(self):
        """
        Try to save score through the app DB.
        If the app environment does not exist, fall back to printing JSON.
        """
        try:
            app = App.get_running_app()

            # Must have user logged in
            if hasattr(app, "user_id") and app.user_id is not None:
                from areteDemo.auth import add_score
                add_score(app.user_id, self.current_score)
                return

        except Exception as e:
            print("In-app score save failed:", e)

        # Fallback: print score for external process capture
        print(json.dumps({"score": self.current_score}))

    # ----------------------------------------------------------
    # STOP (when navigating away)
    # ----------------------------------------------------------
    def stop(self):
        """
        Cleanup method when leaving GameScreen.
        """
        try:
            Clock.unschedule(self._update_event)
        except Exception:
            pass
